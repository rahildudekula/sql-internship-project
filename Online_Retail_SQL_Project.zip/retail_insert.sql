
INSERT INTO Customers VALUES (1, 'Ravi', 'ravi@example.com', '9876543210');

INSERT INTO Products VALUES
(101, 'Laptop', 55000, 10),
(102, 'Mouse', 500, 50);

INSERT INTO Orders VALUES (201, 1, '2025-07-10');

INSERT INTO OrderDetails VALUES
(201, 101, 1),
(201, 102, 2);

INSERT INTO Payments VALUES
(301, 201, 56000, '2025-07-11');
